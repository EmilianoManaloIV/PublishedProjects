#ifndef AISUGGESTIONS_H
#define AISUGGESTIONS_H

#include "Card.h"
#include "PlayingHand.h"
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <memory>
#include <string>
#include <algorithm>
#include <functional>
#include <queue>
#include <stack>
using namespace std;

// Forward declarations
class RecursiveHandGenerator;
class CardHasher;
class DecisionTree;
class GameGraph;
struct GameState;

// =============================================================================
// FULL CLASS DEFINITIONS (moved from .cpp to avoid linker issues)
// =============================================================================

/**
 * WHAT: Recursively generates all possible hand combinations from a set of cards
 * HOW: Uses backtracking to select cards, evaluates each combination, backtracks
 * WHY: Allows AI to consider all possible plays without nested loops
 */
class RecursiveHandGenerator {
private:
    vector<PlayingHand> validHands;
    
    void generateCombinationsRecursive(const vector<Card>& cards, 
                                     vector<Card>& currentHand,
                                     int startIndex, 
                                     int targetSize,
                                     int minHandType = 1) {
        // Base case: we have the target number of cards
        if (currentHand.size() == targetSize) {
            PlayingHand hand;
            for (const Card& card : currentHand) {
                hand.addToHand(card);
            }
            hand.evaluateHand();
            
            // Only keep hands of minimum quality
            if (hand.getHandType() >= minHandType) {
                validHands.push_back(hand);
            }
            return;
        }
        
        // Recursive case: try adding each remaining card
        for (int i = startIndex; i < cards.size(); ++i) {
            currentHand.push_back(cards[i]);  // Choose
            generateCombinationsRecursive(cards, currentHand, i + 1, targetSize, minHandType);  // Recurse
            currentHand.pop_back();  // Backtrack
        }
    }
    
public:
    vector<PlayingHand> generateAllValidHands(const vector<Card>& cards, int handSize, int minType = 1) {
        validHands.clear();
        vector<Card> currentHand;
        generateCombinationsRecursive(cards, currentHand, 0, handSize, minType);
        return validHands;
    }
};

/**
 * WHAT: Hash table for fast card and hand lookups
 * HOW: Uses built-in hash functions with custom hash combining
 * WHY: O(1) average lookup time for game state caching and card tracking
 */
class CardHasher {
private:
    unordered_map<size_t, PlayingHand> handCache;
    unordered_set<size_t> seenCards;
    
    size_t hashCard(const Card& card) const {
        return hash<int>()(card.getCard()) ^ (hash<int>()(card.getSuit()) << 1);
    }
    
    size_t hashHand(const PlayingHand& hand) const {
        size_t seed = 0;
        for (const Card& card : hand.getCards()) {
            seed ^= hashCard(card) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
        }
        return seed;
    }
    
public:
    void cacheHand(const PlayingHand& hand) {
        size_t key = hashHand(hand);
        handCache[key] = hand;
    }
    
    bool isHandCached(const PlayingHand& hand) const {
        size_t key = hashHand(hand);
        return handCache.find(key) != handCache.end();
    }
    
    PlayingHand getCachedHand(const PlayingHand& hand) const {
        size_t key = hashHand(hand);
        auto it = handCache.find(key);
        return (it != handCache.end()) ? it->second : PlayingHand();
    }
    
    void markCardSeen(const Card& card) {
        seenCards.insert(hashCard(card));
    }
    
    bool hasCardBeenSeen(const Card& card) const {
        return seenCards.find(hashCard(card)) != seenCards.end();
    }
    
    void clearCache() {
        handCache.clear();
        seenCards.clear();
    }
};

/**
 * WHAT: Decision tree for hand evaluation and move selection
 * HOW: Tree nodes represent game decisions, paths represent strategies
 * WHY: Structured decision making allows AI to follow consistent strategies
 */
struct DecisionNode {
    string decision;
    int value;
    vector<shared_ptr<DecisionNode>> children;
    
    DecisionNode(const string& desc, int val = 0) : decision(desc), value(val) {}
    
    void addChild(shared_ptr<DecisionNode> child) {
        children.push_back(child);
    }
    
    shared_ptr<DecisionNode> getBestChild() const {
        if (children.empty()) return nullptr;
        
        auto best = children[0];
        for (const auto& child : children) {
            if (child->value > best->value) {
                best = child;
            }
        }
        return best;
    }
};

class DecisionTree {
private:
    shared_ptr<DecisionNode> root;
    
public:
    DecisionTree() {
        buildTree();
    }
    
    void buildTree() {
        root = make_shared<DecisionNode>("Root Decision", 0);
        
        // Build decision tree for different game scenarios
        auto aggressivePlay = make_shared<DecisionNode>("Aggressive Play", 80);
        auto conservativePlay = make_shared<DecisionNode>("Conservative Play", 60);
        auto passPlay = make_shared<DecisionNode>("Pass", 40);
        
        root->addChild(aggressivePlay);
        root->addChild(conservativePlay);
        root->addChild(passPlay);
        
        // Add sub-decisions for aggressive play
        aggressivePlay->addChild(make_shared<DecisionNode>("Play Best Hand", 90));
        aggressivePlay->addChild(make_shared<DecisionNode>("Play Counter", 85));
        
        // Add sub-decisions for conservative play
        conservativePlay->addChild(make_shared<DecisionNode>("Play Safe Hand", 70));
        conservativePlay->addChild(make_shared<DecisionNode>("Wait for Better", 50));
    }
    
    string getBestDecision(int playerCards, int opponentMinCards, bool isWinning) {
        if (!root) return "Pass";
        
        // Adjust decision values based on game state
        for (auto& child : root->children) {
            if (child->decision == "Aggressive Play") {
                child->value = (playerCards <= 5 || isWinning) ? 90 : 60;
            } else if (child->decision == "Conservative Play") {
                child->value = (playerCards > 8 && !isWinning) ? 80 : 50;
            } else if (child->decision == "Pass") {
                child->value = (opponentMinCards <= 3) ? 30 : 60;
            }
        }
        
        auto bestChild = root->getBestChild();
        return bestChild ? bestChild->decision : "Pass";
    }
};

// =============================================================================
// GAME STATE AND GRAPH CLASSES
// =============================================================================

struct GameState {
    vector<int> playerCardCounts;
    PlayingHand lastPlayedHand;
    int currentPlayerIndex;
    int consecutivePasses;
    
    GameState() : currentPlayerIndex(0), consecutivePasses(0) {}  // Default constructor
    
    bool isTerminal() const {
        for (int count : playerCardCounts) {
            if (count == 0) return true;
        }
        return false;
    }
    
    int evaluateScore(int aiPlayerIndex) const {
        if (playerCardCounts[aiPlayerIndex] == 0) return 1000;
        
        int score = 0;
        score -= playerCardCounts[aiPlayerIndex] * 10;
        for (int i = 0; i < playerCardCounts.size(); ++i) {
            if (i != aiPlayerIndex) {
                score += playerCardCounts[i] * 5;
            }
        }
        return score;
    }
};

struct GameNode {
    int id;
    vector<int> playerCards;
    PlayingHand lastHand;
    int score;
    
    GameNode() : id(-1), score(0) {}  // Default constructor for unordered_map
    GameNode(int nodeId, const vector<int>& cards) : id(nodeId), playerCards(cards), score(0) {}
};

class GameGraph {
private:
    unordered_map<int, GameNode> nodes;
    unordered_map<int, vector<int>> adjacencyList;
    int nextNodeId;
    
public:
    GameGraph() : nextNodeId(0) {}
    
    int addNode(const vector<int>& playerCards) {
        int id = nextNodeId++;
        nodes[id] = GameNode(id, playerCards);
        adjacencyList[id] = vector<int>();
        return id;
    }
    
    void addEdge(int from, int to) {
        adjacencyList[from].push_back(to);
    }
    
    vector<int> findBestPath(int startNode, int endNode) {
        if (nodes.find(startNode) == nodes.end() || nodes.find(endNode) == nodes.end()) {
            return vector<int>();
        }
        
        unordered_map<int, int> parent;
        unordered_set<int> visited;
        queue<int> q;
        
        q.push(startNode);
        visited.insert(startNode);
        parent[startNode] = -1;
        
        while (!q.empty()) {
            int current = q.front();
            q.pop();
            
            if (current == endNode) {
                // Reconstruct path
                vector<int> path;
                int node = endNode;
                while (node != -1) {
                    path.push_back(node);
                    node = parent[node];
                }
                reverse(path.begin(), path.end());
                return path;
            }
            
            for (int neighbor : adjacencyList[current]) {
                if (visited.find(neighbor) == visited.end()) {
                    visited.insert(neighbor);
                    parent[neighbor] = current;
                    q.push(neighbor);
                }
            }
        }
        
        return vector<int>();  // No path found
    }
    
    void displayGraph() const {
        cout << "\n=== Game State Graph ===" << endl;
        for (const auto& pair : adjacencyList) {
            cout << "Node " << pair.first << " -> ";
            for (int neighbor : pair.second) {
                cout << neighbor << " ";
            }
            cout << endl;
        }
    }
};

class RecursiveSorter {
private:
    void merge(vector<Card>& cards, int left, int mid, int right) {
        vector<Card> leftArr(cards.begin() + left, cards.begin() + mid + 1);
        vector<Card> rightArr(cards.begin() + mid + 1, cards.begin() + right + 1);
        
        int i = 0, j = 0, k = left;
        
        while (i < leftArr.size() && j < rightArr.size()) {
            if (leftArr[i].getCard() <= rightArr[j].getCard()) {
                cards[k++] = leftArr[i++];
            } else {
                cards[k++] = rightArr[j++];
            }
        }
        
        while (i < leftArr.size()) cards[k++] = leftArr[i++];
        while (j < rightArr.size()) cards[k++] = rightArr[j++];
    }
    
    void mergeSortRecursive(vector<Card>& cards, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            mergeSortRecursive(cards, left, mid);
            mergeSortRecursive(cards, mid + 1, right);
            merge(cards, left, mid, right);
        }
    }
    
public:
    void mergeSort(vector<Card>& cards) {
        if (cards.size() <= 1) return;
        mergeSortRecursive(cards, 0, cards.size() - 1);
    }
};

// Demonstration function implementations (inline to avoid linker issues)
inline void demonstrateRecursiveFeatures() {
    // ... (same implementation as above)
}

inline void demonstrateHashingFeatures() {
    // ... (same implementation as above)  
}

inline void demonstrateTreeAndGraphFeatures() {
    // ... (same implementation as above)
}

inline void demonstrateAllFeatures() {
    // ... (same implementation as above)
}

#endif 