# Big2 Card Game with Advanced AI

A C++ implementation of the popular Big2 (Big Two) card game featuring advanced AI algorithms including recursion, hashing, trees, and graphs.

## Features

- **Complete Big2 Game Implementation**: Full rule set and gameplay
- **Advanced AI Algorithms**: 
  - Recursive hand generation using backtracking
  - Hash tables for performance optimization
  - Decision trees for strategic AI behavior
  - Graph structures for game state analysis
- **Enhanced STL Usage**: Comprehensive use of C++ Standard Template Library
- **Smart AI Players**: Strategic decision-making with multiple algorithms

## Technical Highlights

- **Recursion**: Backtracking for optimal hand combinations
- **Hashing**: O(1) lookup times for game state caching
- **Trees**: Decision trees for AI strategy selection
- **Graphs**: Game state modeling and pathfinding

## Files

- `main.cpp` - Main game loop and logic
- `Card.h` - Card class implementation
- `Deck.h` - Deck management
- `Player.h` - Player and enhanced AI logic
- `PlayingHand.h` - Hand evaluation and comparison
- `AiSuggestions.h/cpp` - Advanced AI algorithms
- `projectDocumentation.txt` - Comprehensive project documentation

## Compilation

```bash
g++ -std=c++11 main.cpp AiSuggestions.cpp -o main.exe
```

## Usage

```bash
./main.exe
```

## Game Rules

Big2 is a shedding-type card game where:
- 4 players start with 13 cards each
- Player with 3 of clubs starts
- Players must play higher combinations than previous player
- First player to empty their hand wins

## AI Demonstration

The program includes comprehensive demonstrations of all advanced algorithms in action.

## Documentation

See `projectDocumentation.txt` for detailed technical documentation, class descriptions, and algorithm analysis. 