#include "AiSuggestions.h"
#include <iostream>
using namespace std;

// =============================================================================
// DEMONSTRATION FUNCTIONS ONLY
// =============================================================================

void demonstrateRecursiveFeatures() {
    cout << "\n=== RECURSIVE FEATURES DEMONSTRATION ===" << endl;
    
    // Create test cards
    vector<Card> testCards = {
        Card(1, 1), Card(1, 2), Card(2, 1), Card(2, 2), Card(3, 1)
    };
    
    // Demonstrate recursive hand generation
    RecursiveHandGenerator generator;
    vector<PlayingHand> hands = generator.generateAllValidHands(testCards, 2, 1);
    cout << "Generated " << hands.size() << " valid 2-card hands recursively" << endl;
    
    // Demonstrate recursive sorting
    RecursiveSorter sorter;
    vector<Card> unsortedCards = testCards;
    sorter.mergeSort(unsortedCards);
    cout << "Cards sorted using recursive merge sort" << endl;
    
    // Demonstrate game state analysis
    GameState state;
    state.playerCardCounts = {5, 7, 8, 6};
    state.currentPlayerIndex = 0;
    state.consecutivePasses = 0;
    
    cout << "Game state created with " << state.playerCardCounts.size() << " players" << endl;
    cout << "Game is " << (state.isTerminal() ? "terminal" : "ongoing") << endl;
    cout << "Score evaluation: " << state.evaluateScore(0) << endl;
}

void demonstrateHashingFeatures() {
    cout << "\n=== HASHING FEATURES DEMONSTRATION ===" << endl;
    
    CardHasher hasher;
    
    // Test card hashing
    Card testCard(5, 2);
    hasher.markCardSeen(testCard);
    
    if (hasher.hasCardBeenSeen(testCard)) {
        cout << "Card successfully tracked using hash table" << endl;
    }
    
    // Test hand caching
    PlayingHand testHand;
    testHand.addToHand(Card(1, 1));
    testHand.addToHand(Card(1, 2));
    testHand.evaluateHand();
    
    hasher.cacheHand(testHand);
    if (hasher.isHandCached(testHand)) {
        cout << "Hand successfully cached using hash table" << endl;
        cout << "Cached hand type: " << testHand.getHandType() << endl;
    }
    
    hasher.clearCache();
    cout << "Cache cleared successfully" << endl;
}

void demonstrateTreeAndGraphFeatures() {
    cout << "\n=== TREE AND GRAPH FEATURES DEMONSTRATION ===" << endl;
    
    // Demonstrate decision tree
    DecisionTree tree;
    string decision1 = tree.getBestDecision(3, 5, false);
    string decision2 = tree.getBestDecision(10, 3, false);
    string decision3 = tree.getBestDecision(2, 8, true);
    
    cout << "Decision tree recommendations:" << endl;
    cout << "  Scenario 1 (3 cards, opp: 5, losing): " << decision1 << endl;
    cout << "  Scenario 2 (10 cards, opp: 3, losing): " << decision2 << endl;
    cout << "  Scenario 3 (2 cards, opp: 8, winning): " << decision3 << endl;
    
    // Demonstrate GameState
    GameState gameState;
    gameState.playerCardCounts = {3, 7, 5, 9};
    gameState.currentPlayerIndex = 0;
    gameState.consecutivePasses = 1;
    
    cout << "\nGame State Analysis:" << endl;
    cout << "  Player card counts: ";
    for (int count : gameState.playerCardCounts) {
        cout << count << " ";
    }
    cout << endl;
    cout << "  Current player: " << gameState.currentPlayerIndex << endl;
    cout << "  Consecutive passes: " << gameState.consecutivePasses << endl;
    cout << "  Game terminal: " << (gameState.isTerminal() ? "Yes" : "No") << endl;
    cout << "  AI (Player 0) score: " << gameState.evaluateScore(0) << endl;
    
    // Demonstrate game graph
    GameGraph graph;
    int node1 = graph.addNode({13, 13, 13, 13});
    int node2 = graph.addNode({12, 13, 13, 13});
    int node3 = graph.addNode({11, 13, 13, 13});
    
    graph.addEdge(node1, node2);
    graph.addEdge(node2, node3);
    
    vector<int> path = graph.findBestPath(node1, node3);
    cout << "Found path through game graph with " << path.size() << " states" << endl;
    
    graph.displayGraph();
}

void demonstrateAllFeatures() {
    cout << "\n" << string(60, '=') << endl;
    cout << "BIG2 ADVANCED ALGORITHMS DEMONSTRATION" << endl;
    cout << string(60, '=') << endl;
    
    demonstrateRecursiveFeatures();
    demonstrateHashingFeatures();
    demonstrateTreeAndGraphFeatures();
    
    cout << "\n" << string(60, '=') << endl;
    cout << "DEMONSTRATION COMPLETE" << endl;
    cout << string(60, '=') << endl;
} 